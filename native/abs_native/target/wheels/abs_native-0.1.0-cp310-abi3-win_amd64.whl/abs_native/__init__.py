from .abs_native import *

__doc__ = abs_native.__doc__
if hasattr(abs_native, "__all__"):
    __all__ = abs_native.__all__